// let person = {
//     name: "Vikas",
//     age: 20,
//     language: "javaScript"
// }
// console.log(person);

// function square(number) {
//     return number*number
// }
// let number = square(7)
// console.log(number);

// function square(number) {
//     return number*number
// }

// console.log(square(9));


// let x = 2;
// let y = 2;
// console.log(x + y);
// console.log(x- y);
// console.log(x * y);
// console.log(x / y);
// console.log(x % y);
// console.log(x ** y);

// increment operator and decrement
// console.log(x++);
// console.log(x);

// x = x - 2
// console.log(x);

// x *= 2
// console.log(x);

// console.log(x>2);
// console.log(x>=2);
// console.log(x<2);
// console.log(x<=2);


// console.log(x===2);
// console.log(x!==2);

// console.log(1===1);
// console.log(1=='1');
// console.log(1==1);
// console.log(0==false);
