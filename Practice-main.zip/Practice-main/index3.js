/ let points  = 110;
// let type = points > 100 ? "Gold" : "silver"
// console.log(type);

// console.log(false && false);

// let highIncome = true; // logical AND operator
// let goodCredit = true;
// let eligible = (highIncome && goodCredit)
// let eligiblE = !eligible
// console.log(eligible);
// console.log(eligiblE);

// console.log(true || false);
// console.log("Vk" || false);
// console.log(true || true);
// console.log(false || 0);

// let userColor = undefined;
// let defaultColor = "Blue";
// let currentColor = userColor || defaultColor
// console.log(currentColor);

// let 1 = 00000001
// let 2 = 00000010
// console.log(4&4);
// console.log(1&0);

// let readPermission = 4;
// let writePermission = 2;
// let executePermission = 1;
// let myPermission = 0;
// myPermission = myPermission | writePermission
// let message = 
// (myPermission & readPermission) ? 'yes' : 'no'
// console.log(message);

// let z = 3
// let v = ++z
// console.log(v);

// let a = "red"
// let b = "blue"
// let c = a
// a = b
// b = c
// console.log(a);
// console.log(b);


// let num1 = 4
// let num2 = 5
// console.log(num1);
// console.log(num2);
// let num3 = num1
// num1 = num2
// num2 = num3
// console.log(num1);
// console.log(num2);

// let a = 5
// let b = 10



// a = a^b
// b = a^b
// a = a^b
// console.log(a);
// console.log(b);
