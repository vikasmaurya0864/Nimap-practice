// console.log("Hello");
// prgram bubble sort to sort array /values
// let data = [2,4,6,8,98,77,44,32,11,12,55,77,77]
// for(let i = 0;i<data.length;i++){
//     for(let j = 0;j<data.length;j++){
//         if(data[j]>data[j+1]){
//             let temp = data[j]
//             data[j] = data[j+1]
//             data[j+1]=temp
//         }
//     }
// }
// console.log(data);

// const { reset } = require("nodemon");

// const { reset } = require("nodemon");
