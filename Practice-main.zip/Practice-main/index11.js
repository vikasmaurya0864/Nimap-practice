
// const calculate = function (radius,logic){
//     let output = []
//     for(let i =0;i<radius.length;i++){
//         output.push(logic(radius[i]))
//     }
//     return  output
// }
// console.log(radius.map(logic));


// let array = [1,2,3,4,5]
// let mult2 = function (array){
//     return array*630
// }
// let b = array.map(mult2)
// console.log(b);

// let array = [1,2,3,4,5]

// function binary(array){
//     return array.toString(2)
// }
// let b  = array.map(binary)
// console.log(b);
// for(let i =0;i<b.length;i++){
//     parseInt(b)
//     console.log(b[i]);
// }
// console.log(b);


// let array = [1,2,10,3,4,5,6,7,8,9]
// function isEven(array){
//     array.sort()
// }
// let output = array.reverse(isEven)
// console.log(output);

// let array = [1,2,3,4,5,6,7,8,9,0,10,11,22,33,44,55,66]
// function max(array){
//     return array>=10;
// }

// let output = array.filter(max)
// console.log(output);

// let data = [1,2,3,4,5,6,7,8,9]
// for(let i = 0;i<data.length;i++){
//     if(data[0]>data[1]){
//         console.log(`${data[0]} is greater`);
//     }
//     else if(data[1]>data[2]){
//         console.log(`${data[1]} is greater`);
//     }
//     else if(data[2]>data[3]){
//         console.log(`${data[2]} is greater`);
//     }
//     else if(data[3]>data[4]){
//         console.log(`${data[3]} is greater`);
//     }
//     else if(data[4]>data[5]){
//         console.log(`${data[4]} is greater`);
//     }
//     else if(data[5]>data[6]){
//         console.log(`${data[5]} is greater`);
//     }
//     else if(data[6]>data[7]){
//         console.log(`${data[6]} is greater`);
//     }
// }



// let data = [10,20,30,400]
// function addSum(data){
//     let sum = 0
//     for(let i =0;i<data.length;i++){
//         sum = sum + data[i]
//     }
//     return sum
// }
// console.log(addSum(data))

// let array = [10,20,30,400]
// let output = array.reduce(function(sum,value){
//     sum = sum + value
//     return sum
// })
// console.log(output);



// let array = [1000,2234230,400]
// let output = array.reduce(function (max,value){
//     if(value>max){
//         max=value
//     }
//     return max
// })
// console.log(output);
