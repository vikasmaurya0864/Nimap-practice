// let number="123456789"
// let splitnumber=number.split('')
// console.log(splitnumber);

// let num = 12345
// function reverse(num){
//     return(
//        parseFloat (
//             num
//             //.split('')
//             .reverse()
//             .join('')

//         )
//     )
// }
// console.log(reverse(num));
// let data = [1,22,33,44,99,99,88,12];
// let max1 = 0;
// let max2 = 0;
// for(let i = 0;i<data.length;i++){
//     if(data[i]>max1){
//         max2=max1;
//         max1=data[i];
//     }
//     else if(data[i]>max2){
//         max2=data[i]
//     }
// }
// console.log(max2);
// let num = 2341;
// let store = "";
// while(num>0){
//    let rem=num%10
//    store+=rem
//     num=Math.floor(num/10)
// }
// console.log(Number(store));
// let num = 35;
// let store = '';
// while(num>0){
//     let rem=num%10
//     store+=rem
//     num=Math.floor(num/10)
// }
// console.log(store);
// let data = [1,2,3,45,66];
// data[3] = undefined
// console.log(data);

// let data = [1,2,3,45,66];
// let position = 3;
// for(let i = position;i<data.length;i++){
//     // console.log(data[i]);
//     data[i]=data[i+1]
// }
// data.length = data.length-1
// console.log(data);


// let data = [1,22,77,65,90,333];
// let max = data[0];
// for(let i =0;i<data.length;i++){
//     if(data[i]>max){
//         max=data[i]
//     }
// }
// console.log(max);
// let num1 = 20;
// let num2 = 50;
// num1=num2-num1
// num2=num2-num1
// num1=num1+num2
// console.log(num1);
// console.log(num2);

// let num1 = 10;
// let num2 = 20;
// let num3 = num1 //1
// num1=num2 //1
// num2=num3

// console.log(num1);
// console.log(num2);
// let data = [1,22,33,94,77,97,96,44,56,666,888];        2nd max by Satya Bhai
// let max1  = 0
// let max2 = 0
// for(let i = 0;i<data.length;i++){
//     if(data[i]>max1){
//         max2=max1
//         max1 = data[i]
//     }
//     else if(data[i]>max2) {
//         max2=data[i]
//     }
// }
// console.log(max2);

// //i=0=>1
// //max1=0
// //max2=0


// //i=1=>

// let data = [1,22,35,55,11,73,56];
// let max1 = 0;
// let max2 = 0;
// for(let i = 0;i<data.length;i++){
//     if(data[i]>max1){
//         max1 = max2
//         max2 = data[i]
//     }
// }
// console.log(max1);
//i=1 => 22
//max1 = 0
//max2 = 1
// let array = [99, 88, 77, 44, 12,100,1008];
// let max1 = 0;
// let max2 = 0;
// for(let i = 0;i<array.length;i++){
//     if(array[i]>max1){
//         max2=max1
//         max1 = array[i]
//     }
//     else if(array[i]>max2){
//         max2=array[i]
//     }
// }
// console.log(max2);
// let integer = 123;
// function reverse(integer) {
//     let array = [];
//     array.push(integer)
//     console.log(array);
//     array.reverse()

// }

// (reverse(integer))
// 123%10=3
// // 12%10=2
// // 1
// [1,1,2,2,2]
