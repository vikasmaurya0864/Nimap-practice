// 28/11/2022
// console.log("Vikas");
// let num1 = 10;
// let num2 = 20;
// num1=num1+num2
// num2=num1-num2
// num1=num1-num2
// console.log(num1);
// console.log(num2);

// let data = [1,2,3,4,5,6]
// for(let i = 0;i<data.length;i++){
//         console.log(data[i]);
// }
// console.log(!true);
// "VIkas"
// let a = 5;
// a+=10;
// console.log(a);
// let b = 10%6

// console.log(b);

// let a = 10;
// let b = 2;
// let c = a**b;
// console.log(c);

// let a = 12;
// let b = 10+10;
// console.log(b);

// let a = 10;
// console.log(a++);
// let b = 20;
// console.log(++b);
//10
/*
11
10
11
11
10
10
*/

// let a = 5
// let b = 10
// let c =a**b
// console.log(c);


// let a = 10;
// let b = 10;
// console.log(!false);
// console.log(!true);

// let age = 14;
// if(age>18){
//         console.log("You are old");
// }
// else{
//         console.log("YOu are young");
// }

// let age = 19;
// if(age<18){
//         console.log("YOung");
// }
// else if(age>18 && age<24){
//         console.log("Ok to drive");
// }
// else if(age>24 && age<55){
//         console.log("true");
// }
// else{
//         console.log("Hii");
// }
// let data = [22,5,77,88,99,22,11,454,444];
// let max1 = 0;
// let max2 = 0;
// for(let i = 0;i<data.length;i++){
//         if(data[i]>max1){
//                 max1=data[i]
//         }
// }
// for(let i = 0;i<data.length;i++){
//         if(data[i]>max2 && data[i]<max1){
//                 max2=data[i]
//         }
// }
// console.log(max2);

// let fruits = "banana"
// switch(fruits){
//         case "mango":
//                 console.log("mangoes");
//                 break;
//         case "banana":
//                 console.log("Bananas");
//                 break;
//         case "papayas":
//                 console.log("Papayas");
//                 break;
// }

// let age  = 18;
// let a = ((age>18)? "Heelo" : "bye")
// console.log(a);
// let number = 99;
// if(number%2==0 || number%3==0){
//         console.log("Dividible by 2");
// }
// else{
//         console.log("Not disvisible by 3");
// }

// console.log(2);
// console.log(2);
// console.log(2);
// console.log(2);
// console.log(2);


// let number = 100;
// for(let i = 0;i<=number;i++){
//         console.log(i);
// }
// let number = 10;
// let sum = 0;
// for(let i=0;i<=number;i++){
//         sum+=i
// }
// console.log(sum);
// let n = 20;
// let mult = 1;
// for(let i=0;i<=n;i++){
//         mult*=i
// }
// console.log(mult);
// let marks = {
//         vikas: 45,
//         satya: 46,
//         ms: 88,
// }
// for(let key in marks){
//         console.log(key,marks[key]);
// }
// for(let i of "1234"){
//         console.log(i);
// }
// let marks = {
//         vikas: 56,
//         vika:45,
//         vik: 55,
//         vi: 77
// }
// for(let value of marks){
//         console.log(marks[value]);
// }
// let b =0
// let a = 10;
// while(b<=a){
//        console.log(b);
//        b++; 
// }
// let i = 0;
// let a = 10
// // do{
// //         console.log(i);
// //          ++i
// //         console.log(i)
// // }
// // while(i<a){
//         // console.log(i>a)
//         console.log("55");
// }
// let b = 10;
// let a = 10;
// function avg(a,b){
//         return ((a+b)/2)
// }
// let c = avg(a,b)
// console.log(c);
// let p = 10
// let q = 20
// let sum = (p,q)=>{
//         return p+q 
// }
// let res = sum(5,6)
// console.log(res);

// let hello = () => {
//         return "HelO"
// }
// console.log(hello());

// let marks = {
//         vikas:23,
//         satya:34,
//         vi: 99
// }
// for(let key in marks){
//         console.log(`The marks of ${key} are ${marks[key]}`);
// }

// let marks = {
//         vikas: 4,
//         satya: 55,
//         vi: 33
// }
// for(let keys in marks){
//         console.log(keys,marks[keys]);
// }
// let a=1;
// let b = 2;
// let c = 3;
// let d = 3;
// let e = 3;
//  let mean = (a,b,c,d,e)=>{
//         return (a+b+c+d+e)/5
//  }

// console.log(mean(a,b,c,d,e));

// console.log("Vik\"as");
// let str = "Vikas"
// str[0]="akash"

// console.log(str);

//  let marks =  [22,55,77,66];
// //  console.log(marks[0]);
// //  console.log(marks[1]);
// //  console.log(marks[2]);
// //  console.log(marks[3]);
// //  console.log(marks[4]);
// console.log(marks.length);
//  marks[5] = "Vokas"
// console.log(marks[5]);

// let data = [1,2,3,4,5,6];
// for(let i = 0;i<data.length;i++){
//         console.log(data[i]);
// }
// let array = [22,33,44,55];
// let res = array.toString()
// console.log(res);





// let arr = [1,2,3,4];
// let c  = arr.join(".")
// console.log(c);
// let set = [1,2,3,4,5];
// set.pop()
// console.log(set);
// set.push(4)
// console.log(set);

// let data = [1,2,3,4,5];
// data.shift()
// console.log(data);


// let data = [1,23,4,5];
// data.unshift(23);
// console.log(data);
// let data = [1,2,3,4];
// delete data[3]
// console.log(data);

// let one = [1,2,3,4,5];
// let two = [6,7,8,9,10];
// let three = one.concat(two);
// console.log(three);

// let data = [33,55,6,87,112,1];
// let res = data.sort((a,b)=>{
//         return (a-b)
// })
// console.log(res);

// let data = [122,1323,1,2,3,55,77,67];
// let res = data.sort((a,b)=>{
//         return a-b
// })
// console.log(res);

// let data = [1,3,4,5,6];
// data.splice(0,3,22,33,44,55,66)
// console.log(data);

// let data = [1,2,3,4,5,6,7,7];
// let c = data.slice(2,6)
// console.log(c);
// console.log(data);

// let data =  [1,2,3,4,5,6,7];
// for(let i = 0;i<data.length;i++){
//         console.log(data[i]);
// }
// let data = [1,2,3,4];
// data.forEach((element)=>{
//         console.log(element*element)
// })
// console.log(res(data));

// let name = "Vikas";
// let res = Array.from(name);
// console.log(res);
// let name = {
//         fname: 'vikas',
//         lname: 'satish',
//         mname: 'maurya'
// }
// let output = Array.from(name)
// console.log(output);
