
//constructors

// function Circle(radius){
//     this.radius = radius;
//     this.draw = function(){
//         console.log("draw");
//     }
// }
// let circle1 = new Circle(4)
// console.log(circle1);

// let circle = {
//     radius: 5
// };

// circle.color = "Blue"
// circle.draw = function(){
//     console.log("draw");
// }

// delete circle.color
// delete circle.draw
// console.log(circle);

// let x = 6
// let y = x
// x = 10
// console.log(x);
// console.log(y);


// let data = [1,4,666,33,99,34,9];
// for(let i = data.length;i>=0;i--){
//     // console.log(data[i]);
//     let j = data[0]
//     let k = data[data.length-1]
//     if(j>k){
//         let temp = k
//         k=j
//         j = temp
//     console.log(`${temp} is greater`);
//     }
// }

// counter Token 
// function counter(){

//     let count = 100;
//     this.incrementCounter = function (){
//         count++;
//         console.log(`Your Token is: `);
//         console.log(`${count}`);
//     }
//     this.decrementCounter = function (){
//         count--;
//         console.log(`Your Token is: `);
//         console.log(`${count}`);
//     }

// }

// let counter1  = new counter()
// counter1.incrementCounter()
// counter1.decrementCounter()
