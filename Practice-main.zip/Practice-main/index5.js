// let camera = isLandsape(500,900);

// function isLandsape(width,height){
//     return (width>height) ? "LandScape" : "Portrait"
// }
// console.log(camera);


// const output = fizzBuzz();
// console.log(output);
// function fizzBuzz(input){
//     if(typeof input !=='number'){
//         return NaN
//     }
//     if((input % 3 === 0) && (input % 5 === 0)){
//         return "fizzBuzz"
//     }
//     if(input % 3 === 0){
//         return "Fizz"
//     }
//     if(input % 5 === 0){
//         return "Buzz"
//     }
//     return input

// }

// let speed = checkSpeed(75);

// console.log(speed);
// function checkSpeed(speed){
//     const speedLimit = 70;
//     const kmPerPoint = 5;
//     if(speed<speedLimit + kmPerPoint){
//         console.log("OK");
//     }
//     else{
//        const point = Math.floor( (speed - speedLimit) / kmPerPoint);
//        if(point>=12){
//         console.log("License Suspended");
//        }
//        else{
//         console.log("points",point);
//        }

//     }
// }
// let number = oddEven(10)
// console.log(number);
// function oddEven(input){
//     for(let i = 0;i<=input;i++){
//         if(i % 2 !== 0){
//             console.log(i+ " "+"ODD");
//         }
//         else{
//             console.log(i+ " "+"EVEN");
//         }
//     }
// }
