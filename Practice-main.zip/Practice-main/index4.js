// let a = 5;
// let b = 6;
// [a, b] = [b, a];
//  console.log(a);
// console.log(b);

// let date = new Date()
// let hour = date.getHours()
// if(hour>=6 && hour<12){
//     console.log("Good Morning");
// }
// else if(hour>=12 && hour <15){
//     console.log("Afternoon");
// }
// else if(hour>=15 && hour < 19){
//     console.log(Evening);

// }
// else{
//     console.log("Night");
// }


// let role = 'Relatives';
// switch (role) {
//     case 'guest':
//         console.log("Hello guests");
//         break;
//     case 'relatives':
//         console.log("Relatives");
//         break;
//     case 'Relatives':
//         console.log("reLatives");
//         break;

//     default:
//         break;
// }


// let role = 'relatives';
// if(role === 'guests') console.log("Guests");
// else if(role === 'relatives') console.log("Relatives");

// for (let i = 0; i <= 10; i++) {
//     if(i % 2 !==0) console.log(i);

// }
// let i = 15
// while (i<=10) {
//     if (i % 2 == 0 ) {
//         console.log(i);
//     }
//     i++
// }

// let i = 11;
// do{
//     if(i%2!==0 ) console.log(i);
//     i++
// }while(i<5)

// let i = 0
// while(i<5){
//     console.log(i);
//     i++
// }

// let person = {
//     name: "Vikas",
//     age: 20,
//     subject: "javaScript",
// }
// for(let key in person){
//     console.log(person[key]);
// }

// let colors = ["Red","Green","Blue"]
// for(let index in colors){
//     console.log(colors[index]);
// }

// let colors = ["Red","green","Blue"]
// for(color of colors){
//     console.log(color);
// }

// let i = 0;
// while(i<10){
//     // if(i===5) break;
//     if(i % 2 == 0){
//         i++;
//         continue;
//     }
//     console.log(i);
//     i++
// }
// let num1 = 5; // Find max from given number
// let num2 = 10;
// function maxNumber(num1,num2) {
//     if(num1>num2){ 
//         console.log(`${num1}`); 
// }
// else{
//     console.log(`${num2}`)
// }
// }
// (maxNumber(num1,num2))


// let number  = max(50,10);

// function max(num1,num2){
//     if(num1>num2){
//         return num1
//     }
//     else{
//         return num2
//     }
// }
// console.log(number);


// let number = max(50,100);
// console.log(number);
// function max(num1,num2){
//   return  (num1>num2) ? `${num1}`: `${num2}`
// }
