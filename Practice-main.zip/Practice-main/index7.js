// let circle = {
//     radius: 5,
//     location: {
//         x: 1,
//         y: 2
//     },
//     draw: function () {
//         console.log("hello");
//     }
// };
// (circle.draw());
// console.log(circle);

// let circle = {
//     radius: 5,
//     location: {
//         x:1,
//         y:2
//     },
//     draw: function(){
//         console.log("hello");
//     }
// };
// circle.draw();

// let num = 8
// function square(num){
//     let ans = num*num;
//     return ans;
// }
// console.log(square(num))
// let square2 = square(num)
// console.log(square2);







// pass by value 
// let data = {
//     name: "vikas"
// };
// console.log(data);
// let data2 = {...data}
// // let data2 = JSON.parse(JSON.stringify(data));
// data2.name = "vk";
// console.log(data2);

// console.log(data);



// Max min without using Function
// let data = [1,2,4,7,8,88]
// console.log(Math.max());
// let data = [1,2,4,7,8,88]
// let sum =0
// for(let i of data){
// sum+=i
// }
// console.log(sum);



// let a = 20
// function square(num){
//     return num*num
// }
// let a = square(3)
// console.log(a);

// let data = [2,3,0,55,66,77,12234,4569384]
// let max = data[0];
// for(let i = 0;i<data.length;i++){
//     if(data[i]>max){
//         max = data[i]
//     }
// }console.log(max);


// function createCircle(radius){ //factory functions
//     return{
//     radius,
//     draw(){
//         console.log("draw");
//     }
// }
// }
// let circle1 = createCircle(5)
// console.log(circle1);

