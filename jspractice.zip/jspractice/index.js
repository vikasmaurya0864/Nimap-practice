// let arr = [12, 35, 1, 10, 34, 1, 35];
// let max1 = 0;
// let max2 = 0;
// for(let i = 0;i<arr.length;i++){
//     if(arr[i]>max1){
//         max1=arr[i];  //12,35
//     }
// }
// for(let i=0;i<arr.length;i++){
//     if(arr[i]>max2 && arr[i]<max1){778
//         max2 = arr[i]  //1,10,34,
//     }
// }
// console.log(max2);
// function reverseNumber(number){
//     let revNumber = 0;
//     let a = 0;
//     while(number>0){
//          revNumber = (revNumber*10)+(number%10);
//         number = Math.floor(number/10);
//     }
//     return revNumber;
// }
// let result = reverseNumber(8344);
// console.log("Reverse_Number = ",result);
// let num = 7865;
// let res = 0;
// while(num>0){
//     res = (res*10)+(num%10);
//     num = Math.floor(num/10)
// }
// console.log(res);
// let num = 1234;
// let rem = 0;
// while(num>0){
//     rem = (rem*10)+(num%10);
//     num = Math.floor(num/10);
// }
// console.log(rem)

// let a = 20;
// let b = 40;
// a=a+b
// b=a-b
// a=a-b
// console.log(a);
// console.log(b);

// let str = "viviviviv";
// let len = str.length;
// for(let i =len;i<len/2;i++){
//     if(str[i]!==str[len-1-i]){
//         return "Anagram"
//     }
//     else{
//         return "not anagram"
//     }

// }
// function anagram(str1,str2){
//     let a = Array.from(str1).sort().join('')
//     let b = Array.from(str2).sort().join('');
//     if(a===b){
//         console.log("anagram");
//     }
//     else{
//         console.log("no anagram");
//     }
//     console.log(b);
//     console.log(a);
// }
// anagram("vikas","kasib")
// greet("vikash")
// console.log(a);
// var a = 7;
// function greet(name){
//     console.log(`Hello ${name}`);
// }

// let str = "vikas";
// let res = Array.from(str).reverse();
// let rem = res.join('');
// console.log(rem);

// let data = [1,3,5,7];
// let x = 0;
// for(let i = 0;i<data.length;i++){
//     let a = data[0]
//     let b = data[0+1]

//     if(a>b){
//     data[i+1] = a+1
//     }   
// }
// console.log(data);
// let data = [1, 2, 3, 45];
// let position = 1;
// let element = 100;
// for (let i = data.length - 1; i > 0; i--) {
//     if (i >= position) {
//         data[i + 1] = data[i]
//     }
//     if (i == position) {
//         data[i] = element
//     }
// }
// console.log(data);
// let data = [1,2,3,5];
// let position = 1;
// for(let i = position;i<data.length;i++){
//     data[i]=data[i+1]
// }
// data.length = data.length-1
// console.log(data);
// let arr1 = [1,2,3,4];
// let arr2 = [5,6,7,8,9];
// let arr3 = [...arr1,...arr2]
// console.log(arr3);
// let data = [1,33,11,55,22,44,99,88];
// for(let i = 0;i<data.length;i++){
//     for(let j = 0;j<i;j++){
//         if(data[i]<data[j]){

//             let temp = data[i]
//             data[i]=data[j]
//             data[j]=temp
//         }
//     }
// }
// console.log(data);

// function apple(x){
//    console.log(x);
// if(x<15){
//      apple(x+1);
// }
// }
// let x = 1
// apple(x);


// function factorial(num){
//     if(num==0){
//         return 1
//     }
//     return num *factorial(num-1)
// }
// console.log(factorial(5));

// let data = [1,33,44,55,66];
// let res = data.at(1);
// let res = data.concat(123,456);
// let res = data.copyWithin(3,0,2);
// let res = data.every(check);
// console.log(res);
// function check(num){
//     return num>0
// }
// let data = [1,33,44,55,66];
// // let res = data.fill(1);
// let res = data.filter((value)=>{
//    return  value>2
// })
// console.log(res);
// let data = [8,99,88,77,66];
// let res = data.find((element)=>{
//     return element>8
// });
// console.log(res);

// let data = [2,4,6,8];
// let res = data.map((element)=>{
//    return element*2
// })
// console.log(res);
// let data = [1,2,3,4,5];
// let res = data.reduce((acc,curr)=>{
//     return acc=acc+curr
// })
// console.log(res);

// var x = 10;
// a();
// b();
// console.log(x);

// function a(){
//     var x = 20;
//     console.log(x);
// }
// function b(){
//     var x = 100;
//     console.log(x);
// }
// function a(){
//     console.log(x);
//     function b(){
//         console.log(x);
//     }
//     b();
// }
// let x = 10;
// a();
// var a = 10;
// {
//     console.log(a);
//     var a = 20;
// }

// console.log(b);
// let a  = 20;
// var b = 10;
// let a = 10;
// {
//     console.log(a);
//     let a = 90;
// }
// var a = 10;
// {
//     console.log(a);
//     var a = 30;
// }

// var b = 10;
// function a(){
//     var b= 29
//     console.log(b);
// }
// a();
// try{
//     let a = 20;
//     console.log(a);
// }catch{
//     console.log(err.message);
// }



// function factorial(num){
//     if(num===0){
//         return 1
//     }
//     return num * factorial(num-1)
// }
// console.log(factorial(6));

// let data = ["vikas",'ram','suresh'];
// let a = 0;
// function tr(data){
//     while(a<data.length){
//        return tr(data)
//         data+1
//     }
// }
// console.log(tr(data));
// let data = ["vikas",'ram','surewsjh','hello','simple'];
// let i = 0;
// while(i<data.length){
//     console.log(data[i]);
//     i++
// }

// var a = 10;
// let b = 20;
// function c(){
//     console.log(a);
//     var a = 100;
//     // let b = 1000;
//     console.log(b);
// }

// c();

// {
// var a = 10;
// let b = 20;
// const c = 30;
// console.log(a);
// console.log(b);
// console.log(c);
// }
// console.log(a);
// console.log(b);
// console.log(c);

// function a(){
//     console.log("a called");
// }
// a();

// let b = function(){
//     console.log("b called");
// }
// b();

// let c = function a(){
//     console.log("c called");
// }
// // console.log(c)
// c();

// let num = 5;
// function factorial(num){
//     if(num==0){
//         return 1;
//     }
//     return num * factorial(num-1);
// }
// console.log(factorial(num));
// greet("vikas");
// function greet(name){
//     console.log(`hello ${name}`);
// }
// function a(){
//     console.log(`Good Morning`);
// }
// a();
//  setTimeout (() => {
//     console.log("hello");
// }, 5000);
// for(let i =0;i<1000;i++){
//     console.log(i);
// }

// let radius = [3,5,7,9];
// const diameter = function (radius){
//     return 2 * radius
// }
// const calculate = function (radius,logic){
//     let output = []
//     for(let i =0;i<radius.length;i++){
//         output.push(logic(radius[i]))
//     }
//     return output
// }
// console.log(calculate(radius,diameter));

// const arr = [1,2,3,4];
// const output = arr.map((arr)=>{
//    const res =  arr * 2
//     return res
// })
// console.log(output);
// let arr = [1,2,3,4,8,10];
// function binary(x){
//     return x.toString(2) ;
// }
// const output = arr.map(binary);
// console.log(output);

// let arr = [1,2,3,4,5,6,7,8,9];
// const res = (x)=>{return x>5}

// const output = arr.filter(res);
// console.log(output);

// const arr = [1, 2, 3, 4, 5, 6, 7, 8];
// const isOdd = (x) => { return x % 2 }
// const output = arr.filter(isOdd);
// console.log(output);
// const arr = [1,2,3,4,5];
// const sum = (acc,curr)=>{
//     acc = acc + curr;
//     return acc
// }
// const output = arr.reduce(sum);
// console.log(output);

// const arr = [1,2,3,4,5,10,2];
// const max = (acc,curr)=>{ 
//     acc=curr
//     curr 
//     return acc
// }
// const output = arr.reduce(max);
// console.log(output);
// const data = 'hello hiiell';
// const arr = data.split('');
// let hashMap = {};
// for(let i = 0;i<arr.length;i++){
//     if(!hashMap[arr[i]]){
//         hashMap[arr[i]]=1
//     }
//     else{
//         hashMap[arr[i]]+=1
//     }
// }
// console.log(hashMap);


// var txt = new Array(1,2,3,4,5);
// console.log(txt);
// var x = 4 + "4";
// console.log(x);
// let FirstAndLast = "vikas";
// let _first_and_lastname = "maurya";
// let 2names = "vishal"
// console.log(2names);


// for(var i =0;i<3;i++){
//     setTimeout(() => {
//         console.log(i)
//     }, 1000 * i);
// }


    // var a =6;
    // (function(){
    //     var a=b=5;
    // })();
    // console.log(a);






















    

























































































































































































































































































































































































































































































































































































































































