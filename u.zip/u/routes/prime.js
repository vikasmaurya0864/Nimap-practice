const express = require('express');
const router = express.Router();
const controllers = require('../controllers/primeCustomers');
/* GET users listing. */
router.post('/prime',controllers.createPrime);
router.get('/prime/:id',controllers.getPrime);
router.put('/prime/:id',controllers.updatePrime);
module.exports = router;
