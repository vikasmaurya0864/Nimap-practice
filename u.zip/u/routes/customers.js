const express = require('express');
const router = express.Router();
const controllers = require('../controllers/customersController');
/* GET home page. */
router.post('/customers',controllers.createCustomers);
router.get('/customers',controllers.getCustomers);
router.put('/customers/:id',controllers.updateCustomers);
router.delete('/customers/:id',controllers.deleteCustomers);
module.exports = router;
