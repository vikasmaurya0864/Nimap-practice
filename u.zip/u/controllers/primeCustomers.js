const db = require('../models/index');
const primeUsers = db.prime;

exports.createPrime = async(req,res)=>{
    const data = req.body;
    console.log(data);
    const response = await primeUsers.create(data);
    res.send({'message':'success',result:response});
}
exports.getPrime = async(req,res)=>{
    const userId = req.params.id;
    const response = await primeUsers.findOne({where:{id:userId}});
    if(response){
        res.send({'message':'success',result:response});
    }
    else{
        res.send({'message':'not found',result:response})
    }
}
exports.updatePrime = async(req,res)=>{
    const userId = req.params.id;
    const data = req.body;
    const response = await primeUsers.update(data,{where:{id:userId}});
    res.send({'message': 'success',result:response});
}