// let data = [1,2,4,5];
// let position = 1;
// let element = 100;
// for(let i=data.length-1;i>=1;i--){
//     if(i>=position){
//         data[i+1]= data[i]
//     }
//     if(i==position){
//         data[i]=element
//     }
// }
// console.log(data);

// let data = [2,4,556,6];
// let position = 2;
// for(let i =position;i<data.length;i++){
//     data[i]=data[i+1]
// }
// data.length = data.length-1
// console.log(data);

// let data = [2, 3, 6, 7];
// let searchEl = 7;
// let newEl = "";
// for (let i = 0; i < data.length; i++) {
//     if(data[i]==searchEl){
//          newEl += i
//     }
// }
// console.log(newEl);

// let data = [12,4,67,7];
// let max = 0;
// for(let i = 0;i<data.length;i++){
//     if(data[i]>max){
//         max=data[i]
//     }
// }
// console.log(max);


// function a(){

// }
// console.log(a());


