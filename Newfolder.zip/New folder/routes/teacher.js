const express = require('express');
const router = express.Router();
const controllers = require('../controllers/teacherControllers');
/* GET home page. */
router.post('/teacher',controllers.createTeacher);
router.get('/teacher',controllers.getTeacher);
router.put('/teacher/:id',controllers.updateTeacher);
router.delete('/teacher/:id',controllers.deleteTeacher);

module.exports = router;
