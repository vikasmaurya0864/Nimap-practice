const express = require('express');
const router = express.Router();
const controllers = require('../controllers/studentControllers');
/* GET home page. */
router.post('/student',controllers.createStudent);
router.get('/student',controllers.getStudent);
router.put('/student/:id',controllers.updateStudent);
router.delete('/student/:id',controllers.deleteStudent);

module.exports = router;
