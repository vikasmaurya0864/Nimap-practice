const db = require('../models/index');
const teachers = db.teachers;

exports.createTeacher = async(req,res)=>{
    const data = req.body;
    const response = await teachers.create(data);
    res.send({message: "teacher created successful",result:response});
}
exports.getTeacher = async(req, res)=>{
    const response = await teachers.findAll();
    res.send({'message': "teachers fetched successful",response});
}
exports.updateTeacher = async(req, res)=>{
    const userId = req.params.id;
    const data = req.body;
    const response = await teachers.update(data,{where:{id:userId}});
    res.send({'message': "teacher update successful",response,result:data});
}
exports.deleteTeacher = async(req, res)=>{
    const userId = req.params.id;
    const response = await teachers.destroy({where:{id:userId}});
    res.send({'message': "teacher delete successful",response});
}