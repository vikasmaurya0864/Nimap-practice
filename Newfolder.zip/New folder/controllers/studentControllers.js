const db = require('../models/index');
const students = db.students;

exports.createStudent = async(req,res)=>{
    const data = req.body;
    const response = await db.students.create(data);
    res.send({message: "student created successful",result:response});
}
exports.getStudent = async(req, res)=>{
    const response = await students.findAll();
    res.send({'message': "students fetched successful",response});
}
exports.updateStudent = async(req, res)=>{
    const userId = req.params.id;
    const data = req.body;
    const response = await students.update(data,{where:{id:userId}});
    res.send({'message': "student update successful",response,result:data});
}
exports.deleteStudent = async(req, res)=>{
    const userId = req.params.id;
    const response = await students.destroy({where:{id:userId}});
    res.send({'message': "student delete successful",response});
}