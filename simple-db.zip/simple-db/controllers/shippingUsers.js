const db = require('../models/index');
const shipping = db.shipping;

exports.createShipping = async(req, res)=>{
    const data = req.body;
    const response = await shipping.create(data);
    res.send({'message': "shipping created successful",response});
}

exports.getShipping = async(req, res)=>{
    const data = req.body;
    const response = await shipping.findAll(data);
    res.send({'message': "shipping fetched successful",response});
}
exports.updateShipping = async(req, res)=>{
    const userId = req.params.id;
    const data = req.body;
    const response = await shipping.update(data,{where:{id:userId}});
    res.send({'message': "shipping upload successful.",response});
}
exports.deleteShipping = async(req, res)=>{
    const userId = req.params.id;
    const data = req.body;
    const response = await shipping.destroy({where:{id:userId}});
    res.send({'message': "shipping delete successful.",response});
}