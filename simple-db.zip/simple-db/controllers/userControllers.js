const db = require('../models/index');
const customers = db.customers;
exports.createData = async(req, res)=>{
    const data = req.body;
    const response = await customers.create(data);
    res.send({'message': "data created successful",response});
}

exports.getData = async(req, res)=>{
    const data = req.body;
    const response = await customers.findAll(data);
    res.send({'message': "data fetched successful",response});
}
exports.updateData = async(req, res)=>{
    const userId = req.params.id;
    const data = req.body;
    const response = await customers.update(data,{where:{id:userId}});
    res.send({'message': "data upload successful.",response});
}
exports.deleteData = async(req, res)=>{
    const userId = req.params.id;
    const data = req.body;
    const response = await customers.destroy({where:{id:userId}});
    res.send({'message': "data delete successful.",response});
}