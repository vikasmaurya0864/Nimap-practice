const db = require('../models/index');
const orders = db.orders;

exports.createOrders = async(req, res)=>{
    const data = req.body;
    const response = await orders.create(data);
    res.send({'message': "orders created successful",response});
}

exports.getOrders = async(req, res)=>{
    const data = req.body;
    const response = await orders.findAll(data);
    res.send({'message': "orders fetched successful",response});
}
exports.updateOrders = async(req, res)=>{
    const userId = req.params.id;
    const data = req.body;
    const response = await orders.update(data,{where:{id:userId}});
    res.send({'message': "orders upload successful.",response});
}
exports.deleteOrders = async(req, res)=>{
    const userId = req.params.id;
    const data = req.body;
    const response = await orders.destroy({where:{id:userId}});
    res.send({'message': "orders delete successful.",response});
}