const express = require('express');
const router = express.Router();
const shipping = require('../controllers/shippingUsers');
/* GET users listing. */
router.post('/shipping',shipping.createShipping);
router.get('/shipping',shipping.getShipping);
router.put('/shipping/:id',shipping.updateShipping);
router.delete('/shipping/:id',shipping.deleteShipping);

module.exports = router;