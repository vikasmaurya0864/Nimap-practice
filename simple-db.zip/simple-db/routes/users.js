const express = require('express');
const router = express.Router();
const orders = require('../controllers/orders');
/* GET users listing. */
router.post('/orders',orders.createOrders);
router.get('/orders',orders.getOrders);
router.put('/orders/:id',orders.updateOrders);
router.delete('/orders/:id',orders.deleteOrders);

module.exports = router;
