const express = require('express');
const router = express.Router();
const controllers = require('../controllers/userControllers');
/* GET home page. */
router.post('/customers',controllers.createData);
router.get('/customers',controllers.getData);
router.put('/customers/:id',controllers.updateData);
router.delete('/customers/:id',controllers.deleteData);

module.exports = router;
