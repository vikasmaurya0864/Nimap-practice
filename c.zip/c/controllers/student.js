const db = require('../models/index');
const students = db.students;
const { Op } = require("sequelize");
const jwt=require('jsonwebtoken')

exports.createStudents = async(req, res)=>{
    const data = req.body;
    const response = await students.create(data);
    res.send({'message': "student created successful",response});
}
exports.getStudents = async(req, res)=>{
    const response = await students.findAll();
    res.send({'message': "student fetched successful",response});
}
exports.updateStudents = async(req, res)=>{
    const userId = req.params.id;
    const data = req.body;
    const response = await students.update(data,{where:{id:userId}});
    res.send({'message': "student updated successful",response});
}
exports.deleteStudents = async(req,res)=>{
    const userId = req.params.id;
    const response = await students.destroy({where:{id:userId}});
    res.send({'message': "student deleted successful",response});
}

exports.login=async (req,res)=>{
    const {email,password}=req.body
    const response=await students.findOne({where:{[Op.and]:[{email:email,password:password}]}})
    const token=jwt.sign({id:response.id,name:response.name},"vikash")
    res.send({msg:"successfully login",resut:response,token:token})
}