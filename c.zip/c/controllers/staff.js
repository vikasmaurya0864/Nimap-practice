const db = require('../models/index');
const staff = db.staff;

exports.createStaffs = async(req, res)=>{
    const data = req.body;
    const response = await staff.create(data);
    res.send({'message': "staff created successful",response});
}
exports.getStaffs = async(req, res)=>{
    const response = await staff.findAll();
    res.send({'message': "staff fetched successful",response});
}
exports.updateStaffs = async(req, res)=>{
    const userId = req.params.id;
    const data = req.body;
    const response = await staff.update(data,{where:{id:userId}});
    res.send({'message':'staff updated successful',response});
}
exports.deleteStaffs = async(req, res)=>{
    const userId = req.params.id;
    const response = await staff.destroy({where:{id:userId}});
    res.send({'message':"staff deleted successful",response});
}