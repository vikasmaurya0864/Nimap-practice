const express = require('express');
const router = express.Router();
const controllers = require('../controllers/student');
/* GET home page. */
router.post('/student',controllers.createStudents);
router.get('/student',controllers.getStudents);
router.put('/student/:id',controllers.updateStudents);
router.delete('/student/:id',controllers.deleteStudents);
router.post('/login',controllers.login)


module.exports = router;
