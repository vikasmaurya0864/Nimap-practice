const express = require('express');
const router = express.Router();
const controllers = require('../controllers/staff');
/* GET users listing. */
router.post('/staff',controllers.createStaffs);
router.get('/staff',controllers.getStaffs);
router.put('/staff/:id',controllers.updateStaffs);
router.delete('/staff/:id',controllers.deleteStaffs);
module.exports = router;
